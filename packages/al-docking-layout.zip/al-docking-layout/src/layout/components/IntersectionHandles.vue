<script setup lang="ts">
import { computed, ref } from 'vue'
import { useLayout } from '../composables/useLayout'
import type { SplitNode } from '../core/types'

const props = defineProps<{ parent: SplitNode }>()
const host = ref<HTMLElement>()
const store = useLayout()
const intersections = computed(() =>
  props.parent.children.flatMap((child, childIndex) =>
    child.kind === 'split' && child.direction !== props.parent.direction
      ? child.sizes.slice(0, -1).map((_, nestedIndex) => ({
          child,
          childIndex,
          nestedIndex,
          parentBoundary: childIndex + (childIndex === props.parent.children.length - 1 ? 0 : 1),
        }))
      : [],
  ),
)
function cumulative(values: number[], end: number) {
  return values.slice(0, end).reduce((sum, value) => sum + value, 0)
}
function handleStyle(item: (typeof intersections.value)[number]) {
  const parentAt = cumulative(props.parent.sizes, item.parentBoundary)
  const nestedAt = cumulative(item.child.sizes, item.nestedIndex + 1)
  return props.parent.direction === 'row'
    ? { '--corner-x': `${parentAt}%`, '--corner-y': `${nestedAt}%` }
    : { '--corner-y': `${parentAt}%`, '--corner-x': `${nestedAt}%` }
}
function start(event: PointerEvent, item: (typeof intersections.value)[number]) {
  event.preventDefault()
  event.stopPropagation()
  const element = host.value
  if (!element) return
  const rect = element.getBoundingClientRect()
  const origin = { x: event.clientX, y: event.clientY }
  const parentSizes = props.parent.sizes.slice()
  const childSizes = item.child.sizes.slice()
  const parentIndex = Math.max(0, Math.min(item.parentBoundary - 1, parentSizes.length - 2))
  const nestedIndex = item.nestedIndex
  const move = (next: PointerEvent) => {
    const dx = ((next.clientX - origin.x) / rect.width) * 100
    const dy = ((next.clientY - origin.y) / rect.height) * 100
    const parentDelta = props.parent.direction === 'row' ? dx : dy
    const childDelta = props.parent.direction === 'row' ? dy : dx
    const p = parentSizes.slice()
    p[parentIndex] += parentDelta
    p[parentIndex + 1] -= parentDelta
    const c = childSizes.slice()
    c[nestedIndex] += childDelta
    c[nestedIndex + 1] -= childDelta
    if (p[parentIndex] > 5 && p[parentIndex + 1] > 5) store.setSizes(props.parent.id, p)
    if (c[nestedIndex] > 5 && c[nestedIndex + 1] > 5) store.setSizes(item.child.id, c)
  }
  const up = () => {
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
  }
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
}
</script>
<template>
  <div ref="host" class="intersection-layer" aria-hidden="true">
    <button
      type="button"
      v-for="(item, index) in intersections"
      :key="index"
      class="intersection-handle"
      :style="handleStyle(item)"
      tabindex="-1"
      @pointerdown="start($event, item)"
    />
  </div>
</template>
